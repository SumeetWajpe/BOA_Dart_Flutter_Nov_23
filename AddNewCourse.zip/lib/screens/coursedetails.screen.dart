import 'package:flutter/material.dart';
import 'package:myfirstapp/models/coursemodel.dart';

class CourseDetails extends StatefulWidget {
  final CourseModel theCourse;
  CourseDetails(this.theCourse);

  @override
  State<CourseDetails> createState() => _CourseDetailsState();
}

class _CourseDetailsState extends State<CourseDetails> {
  bool isFavorite = false;

  void changeFavorite() {
    setState(() {
      isFavorite = !isFavorite;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
      ),
      extendBodyBehindAppBar: true,
      body: SingleChildScrollView(
        child:
            Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Image(
            image: NetworkImage(widget.theCourse.imageUrl),
          ),
          ListTile(
            title: Text(
              widget.theCourse.name,
              style:
                  const TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold),
            ),
            subtitle: Text(
              widget.theCourse.subtitle,
              style:
                  const TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
            ),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              InkWell(
                onTap: changeFavorite,
                child: Icon(
                  isFavorite == true ? Icons.favorite : Icons.favorite_outline,
                  color: Colors.red[900],
                ),
              )
            ]),
          ),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Text(
              widget.theCourse.description,
              style: const TextStyle(fontSize: 15.0),
            ),
          )
        ]),
      ),
    );
  }
}
