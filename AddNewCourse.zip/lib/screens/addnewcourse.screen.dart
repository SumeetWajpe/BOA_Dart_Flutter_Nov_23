import 'package:flutter/material.dart';
import 'package:myfirstapp/models/courselist_changenotifier.dart';
import 'package:myfirstapp/models/coursemodel.dart';
import 'package:provider/provider.dart';

class AddNewCourse extends StatefulWidget {
  const AddNewCourse({super.key});

  @override
  State<AddNewCourse> createState() => _AddNewCourseState();
}

class _AddNewCourseState extends State<AddNewCourse> {
  String _txtId = "";
  String _txtCourseName = "";
  String _txtCourseSubtitle = "";
  String _txtCoursePrice = "";
  CourseModel? _newCourse = null;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  Widget _buildCourseId() {
    return TextFormField(
      keyboardType: TextInputType.number,
      decoration: const InputDecoration(labelText: "Id"),
      onSaved: (String? value) {
        _txtId = value as String;
      },
    );
  }

  Widget _buildCourseName() {
    return TextFormField(
      keyboardType: TextInputType.text,
      decoration: const InputDecoration(labelText: "Course Name"),
      onSaved: (String? value) {
        _txtCourseName = value as String;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("New Course"),
        centerTitle: true,
        backgroundColor: Colors.blue[500],
      ),
      body: SingleChildScrollView(
          child: Container(
        margin: const EdgeInsets.all(20.0),
        child: Form(
            key: _formKey,
            child: Column(
              children: [
                _buildCourseId(),
                _buildCourseName(),
                ElevatedButton(
                    onPressed: () {
                      _formKey.currentState!.save();
                      _newCourse = CourseModel(
                          int.parse(_txtId),
                          _txtCourseName,
                          "subtitle",
                          0,
                          "imageUrl",
                          "description");
                      // global data (model - change notification)
                      Provider.of<CourseListChangeNotifier>(context,
                              listen: false)
                          .addNewCourse(_newCourse as CourseModel);
                    },
                    child: const Text("Add New Course"))
              ],
            )),
      )),
    );
  }
}


// FormState