class CourseModel {
  final int id;
  final String name;
  final String subtitle;
  int likes;
  final String imageUrl;
  final String description;

  CourseModel(this.id, this.name, this.subtitle, this.likes, this.imageUrl,
      this.description);
}
