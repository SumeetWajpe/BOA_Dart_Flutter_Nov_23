import 'package:flutter/material.dart';
import 'package:myfirstapp/widgets/onlinetraining.dart';

void main() {
  // runApp(const Center(
  //   child: Text(
  //     "Hello Flutter !",
  //     textDirection: TextDirection.ltr,
  //   ),
  // ));

  runApp(const OnlineTrainingApp());
}
