import 'package:flutter/material.dart';

class CourseListRowsCols extends StatelessWidget {
  const CourseListRowsCols({super.key});

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        Row(
          children: <Widget>[
            Image(
              image: AssetImage("assets/images/React.png"),
              width: 150.00,
            ),
            Padding(
                padding: EdgeInsets.only(left: 10.0, right: 40),
                child: Column(
                  children: <Widget>[
                    Text(
                      "React",
                      style: TextStyle(
                          fontSize: 35.0, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      "A JS Library",
                      style: TextStyle(
                          fontSize: 16.0, fontStyle: FontStyle.italic),
                    ),
                  ],
                )),
            Text(
              "Delete",
              style: TextStyle(color: Colors.red),
            )
          ],
        ),
      ],
    );
  }
}


// Text(
//                 "React",
//                 style: TextStyle(fontSize: 35.0, fontWeight: FontWeight.bold),
//               ),