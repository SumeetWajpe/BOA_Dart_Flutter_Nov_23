import 'package:flutter/material.dart';
import 'package:myfirstapp/models/CourseModel.dart';

class CourseListListView extends StatelessWidget {
  CourseListListView({super.key});
  final List<CourseModel> listofcourses = [
    CourseModel(1, "React", "A JS library", 100,
        "https://pbs.twimg.com/profile_images/446356636710363136/OYIaJ1KK_400x400.png"),
    CourseModel(2, "Node", "A Server FX",200,
        "https://miro.medium.com/v2/resize:fit:800/1*bc9pmTiyKR0WNPka2w3e0Q.png"),
    CourseModel(3, "Angular", "A JS FX",500,
        "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Angular_full_color_logo.svg/2048px-Angular_full_color_logo.svg.png"),
    CourseModel(4, "Flutter", "A Cross Platform solution",200,
        "https://cdn-images-1.medium.com/max/1200/1*5-aoK8IBmXve5whBQM90GA.png")
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(children: <Widget>[
      ...listofcourses.map((course) => Card(
            elevation: 15,
            child: ListTile(
              leading: Image(
                image: NetworkImage(course.imageUrl),
                width: 100,
              ),
              title: Text(
                course.name,
                style: const TextStyle(fontSize: 25.0),
              ),
              subtitle: Text(
                course.subtitle,
                style: const TextStyle(
                    fontSize: 15.0, color: Color.fromARGB(255, 35, 31, 31)),
              ),
              trailing: const InkWell(
                child: Icon(
                  Icons.delete,
                  color: Color.fromARGB(255, 247, 65, 52),
                ),
              ),
            ),
          ))
    ]);
  }
}

// ListTile -> leading,title,subtitle,trailing

// class CourseListListView extends StatelessWidget {
//   CourseListListView({super.key});
//   final List<String> listofcourses = ["React", "Node", "Angular", "Flutter"];

//   @override
//   Widget build(BuildContext context) {
//     return ListView(
//       children: <Widget>[...listofcourses.map((String course) => Text(course))],
//     );
//   }
// }
// [...listofcourses.map((course) => Text(course)) ]

// equal to

//[[Text("React"),Text("Node")]]