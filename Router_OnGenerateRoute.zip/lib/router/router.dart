import 'package:dynamic_navigation/main.dart';
import 'package:flutter/material.dart';

class OurRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case "homeRoute":
        return MaterialPageRoute(builder: (_) => Home());

      case 'aboutRoute':
        var data = settings.arguments as String;
        return MaterialPageRoute(builder: (_) => About(data));
      default:
        return MaterialPageRoute(
            builder: (_) => Scaffold(
                  body: Center(
                      child: Text("No route exists for ${settings.name}")),
                ));
    }
  }
}
