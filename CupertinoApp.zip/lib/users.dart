import 'package:flutter/material.dart';

class User {
  final String name;
  final Color backgroundColor;

  const User(this.name, this.backgroundColor);
}
