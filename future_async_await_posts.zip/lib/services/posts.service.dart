import 'dart:convert';
import 'package:futureapp_posts/models/posts.model.dart';
import 'package:http/http.dart' as http;

class PostsService {
  Future<List<PostModel>> fetchAllPosts() async {
    var url = Uri.https("jsonplaceholder.typicode.com", "posts");
    var response = await http.get(url);
    if (response.statusCode == 200) {
      var postList = (jsonDecode(response.body) as List)
          .map((post) => PostModel.fromJson(post))
          .toList();
      return postList;
    }
    throw Error();
  }
}
