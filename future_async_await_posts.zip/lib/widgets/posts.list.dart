import 'package:flutter/material.dart';
import 'package:futureapp_posts/services/posts.service.dart';

class PostList extends StatefulWidget {
  const PostList({super.key});

  @override
  State<PostList> createState() => _PostListState();
}

class _PostListState extends State<PostList> {
  final PostsService _srvObject = PostsService();

  @override
  void initState() {
    super.initState();
    var listOfPosts = _srvObject.fetchAllPosts();
    print(listOfPosts);
  }

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
