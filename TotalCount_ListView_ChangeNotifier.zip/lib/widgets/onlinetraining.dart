import 'package:flutter/material.dart';
import 'package:myfirstapp/models/courselist_changenotifier.dart';
import 'package:myfirstapp/widgets/courselist_listview_stateful.dart';
import 'package:myfirstapp/widgets/totalcourses.dart';
import 'package:provider/provider.dart';
// import 'package:myfirstapp/widgets/courselist_rows_cols.dart';

class OnlineTrainingApp extends StatelessWidget {
  const OnlineTrainingApp({super.key});
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
        create: (_) => CourseListChangeNotifier(),
        child: MaterialApp(
            home: Scaffold(
                appBar: AppBar(
                  title: const Text("Online Training App"),
                  centerTitle: true,
                  backgroundColor: Colors.blue[500],
                ),
                //body: CourseListStatefulWidget())));
                body: const TotalCourseCount())));
  }
}
