import 'package:flutter/material.dart';
import 'package:myfirstapp/models/courselist_changenotifier.dart';
import 'package:myfirstapp/screens/coursedetails.screen.dart';
import 'package:myfirstapp/widgets/totalcourses.dart';
import 'package:provider/provider.dart';

class CourseListViewCN extends StatefulWidget {
  const CourseListViewCN({super.key});

  @override
  State<CourseListViewCN> createState() => _CourseListViewCNState();
}

class _CourseListViewCNState extends State<CourseListViewCN> {
  @override
  Widget build(BuildContext context) {
    return Consumer<CourseListChangeNotifier>(
        builder: (_, courseListChangeNotifier, __) =>
            ListView(children: <Widget>[
              ...courseListChangeNotifier.listofcourses
                  .map((course) => GestureDetector(
                        onHorizontalDragEnd: (_) {
                          // delete the course (by calling deleteACourse from Change Notifier)
                          courseListChangeNotifier.deleteACourse(course);
                        },
                        child: Card(
                            elevation: 15,
                            child: ListTile(
                              leading: GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              CourseDetails(course)));
                                },
                                child: Image(
                                  image: NetworkImage(course.imageUrl),
                                  width: 100,
                                ),
                              ),
                              title: Text(
                                course.name,
                                style: const TextStyle(fontSize: 25.0),
                              ),
                              subtitle: Text(
                                course.subtitle,
                                style: const TextStyle(
                                    fontSize: 15.0,
                                    color: Color.fromARGB(255, 35, 31, 31)),
                              ),
                              trailing: InkWell(
                                child: const Icon(
                                  Icons.delete,
                                  color: Color.fromARGB(255, 247, 65, 52),
                                ),
                                onTap: () {
                                  courseListChangeNotifier
                                      .deleteACourse(course);
                                },
                              ),
                            )),
                      )),
              TotalCourseCount()
            ]));
  }
}
