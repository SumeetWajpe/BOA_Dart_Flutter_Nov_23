import 'package:flutter/material.dart';
import 'package:myfirstapp/models/courselist_changenotifier.dart';
import 'package:provider/provider.dart';

class TotalCourseCount extends StatelessWidget {
  const TotalCourseCount({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<CourseListChangeNotifier>(
        builder: (_, courseListChangeNotifier, __) => Container(
              margin: const EdgeInsets.all(20.0),
              child: Text(
                  "Total Courses : ${courseListChangeNotifier.listofcourses.length}",
                  style: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue[900])),
            ));
  }
}
