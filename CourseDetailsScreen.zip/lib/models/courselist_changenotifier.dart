import 'package:flutter/material.dart';
import 'package:myfirstapp/models/coursemodel.dart';

class CourseListChangeNotifier extends ChangeNotifier {
  final List<CourseModel> listofcourses = [
    CourseModel(
        1,
        "React",
        "A JS library",
        100,
        "https://pbs.twimg.com/profile_images/446356636710363136/OYIaJ1KK_400x400.png",
        "React is a free and open-source front-end JavaScript library for building user interfaces based on components. It is maintained by Meta and a community of individual developers and companies. React can be used to develop single-page, mobile, or server-rendered applications with frameworks like Next.js"),
    CourseModel(
        2,
        "Node",
        "A Server FX",
        200,
        "https://miro.medium.com/v2/resize:fit:800/1*bc9pmTiyKR0WNPka2w3e0Q.png",
        "Node.js is a cross-platform, open-source JavaScript runtime environment that can run on Windows, Linux, Unix, macOS, and more. Node.js runs on the V8 JavaScript engine, and executes JavaScript code outside a web browser. Node.js lets developers use JavaScript to write command line tools and for server-side scripting. "),
    CourseModel(
        3,
        "Angular",
        "A JS FX",
        500,
        "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Angular_full_color_logo.svg/2048px-Angular_full_color_logo.svg.png",
        "Node.js is a cross-platform, open-source JavaScript runtime environment that can run on Windows, Linux, Unix, macOS, and more. Node.js runs on the V8 JavaScript engine, and executes JavaScript code outside a web browser. Node.js lets developers use JavaScript to write command line tools and for server-side scripting. "),
    CourseModel(
        4,
        "Flutter",
        "A Cross Platform solution",
        200,
        "https://cdn-images-1.medium.com/max/1200/1*5-aoK8IBmXve5whBQM90GA.png",
        "Node.js is a cross-platform, open-source JavaScript runtime environment that can run on Windows, Linux, Unix, macOS, and more. Node.js runs on the V8 JavaScript engine, and executes JavaScript code outside a web browser. Node.js lets developers use JavaScript to write command line tools and for server-side scripting. "),
    CourseModel(
        5,
        "Redux",
        "State Management",
        200,
        "https://everyday.codes/wp-content/uploads/2020/01/0-U2DmhXYumRyXH6X1.png",
        "Node.js is a cross-platform, open-source JavaScript runtime environment that can run on Windows, Linux, Unix, macOS, and more. Node.js runs on the V8 JavaScript engine, and executes JavaScript code outside a web browser. Node.js lets developers use JavaScript to write command line tools and for server-side scripting. ")
  ];

  void deleteACourse(CourseModel course) {
    listofcourses.removeWhere((theCourse) => theCourse.id == course.id);
    notifyListeners();
  }
}
