package com.example.using_camera

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
