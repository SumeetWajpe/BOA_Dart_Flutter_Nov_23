import 'package:flutter/material.dart';
import 'package:myfirstapp/models/courselist_changenotifier.dart';
import 'package:myfirstapp/models/coursemodel.dart';
import 'package:provider/provider.dart';

class AddNewCourse extends StatefulWidget {
  const AddNewCourse({super.key});

  @override
  State<AddNewCourse> createState() => _AddNewCourseState();
}

class _AddNewCourseState extends State<AddNewCourse> {
  String _txtId = "";
  String _txtCourseName = "";
  String _txtCourseSubtitle = "";
  String _txtCoursePrice = "";
  String _txtCourseLikes = "";

  String _txtCourseImageUrl = "";
  String _txtCourseDesc = "";

  CourseModel? _newCourse = null;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  Widget _buildCourseId() {
    return TextFormField(
      keyboardType: TextInputType.number,
      validator: (String? value) {
        if (value!.isEmpty) {
          return "Id Required !";
        }
        return null;
      },
      decoration: const InputDecoration(labelText: "Id"),
      onSaved: (String? value) {
        _txtId = value as String;
      },
    );
  }

  Widget _buildCourseName() {
    return TextFormField(
      keyboardType: TextInputType.text,
      validator: (String? value) {
        if (value!.isEmpty) {
          return "Name is Required !";
        } else if (value.length > 20) {
          return "Name exceeding 20 chars !";
        }
        return null;
      },
      decoration: const InputDecoration(labelText: "Course Name"),
      onSaved: (String? value) {
        _txtCourseName = value as String;
      },
    );
  }

  Widget _buildCourseSubtitle() {
    return TextFormField(
      keyboardType: TextInputType.text,
      validator: (String? value) {
        if (value!.isEmpty) {
          return "Subtitle is Required !";
        }
        return null;
      },
      decoration: const InputDecoration(labelText: "Course Subtitle"),
      onSaved: (String? value) {
        _txtCourseSubtitle = value as String;
      },
    );
  }

  Widget _buildCourseLikes() {
    return TextFormField(
      keyboardType: TextInputType.number,
      validator: (String? value) {
        if (value!.isEmpty) {
          return "Likes is Required !";
        }
        return null;
      },
      decoration: const InputDecoration(labelText: "Course Subtitle"),
      onSaved: (String? value) {
        _txtCourseLikes = value as String;
      },
    );
  }

  Widget _buildCourseImageUrl() {
    return TextFormField(
      keyboardType: TextInputType.text,
      validator: (String? value) {
        if (value!.isEmpty) {
          return "ImageUrl is Required !";
        }
        return null;
      },
      decoration: const InputDecoration(labelText: "Course ImageURL"),
      onSaved: (String? value) {
        _txtCourseImageUrl = value as String;
      },
    );
  }

  Widget _buildCourseDesc() {
    return TextFormField(
      keyboardType: TextInputType.multiline,
      validator: (String? value) {
        if (value!.isEmpty) {
          return "Decription is Required !";
        }
        return null;
      },
      decoration: const InputDecoration(labelText: "Course Description"),
      onSaved: (String? value) {
        _txtCourseDesc = value as String;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("New Course"),
        centerTitle: true,
        backgroundColor: Colors.blue[500],
      ),
      body: SingleChildScrollView(
          child: Container(
        margin: const EdgeInsets.all(20.0),
        child: Form(
            key: _formKey,
            child: Column(
              children: [
                _buildCourseId(),
                _buildCourseName(),
                _buildCourseSubtitle(),
                _buildCourseLikes(),
                _buildCourseImageUrl(),
                _buildCourseDesc(),
                ElevatedButton(
                    onPressed: () {
                      if (!_formKey.currentState!.validate()) {
                        return;
                      }
                      _formKey.currentState!.save();
                      _newCourse = CourseModel(
                          int.parse(_txtId),
                          _txtCourseName,
                          _txtCourseSubtitle,
                          int.parse(_txtCourseLikes),
                          _txtCourseImageUrl,
                          _txtCourseDesc);
                      // global data (model - change notification)
                      Provider.of<CourseListChangeNotifier>(context,
                              listen: false)
                          .addNewCourse(_newCourse as CourseModel);
                      Navigator.pop(context);
                    },
                    child: const Text("Add New Course"))
              ],
            )),
      )),
    );
  }
}


// FormState