import 'package:flutter/material.dart';
import 'package:myfirstapp/models/courselist_changenotifier.dart';
import 'package:myfirstapp/widgets/onlinetraining.dart';
import 'package:provider/provider.dart';

void main() {
  // runApp(const Center(
  //   child: Text(
  //     "Hello Flutter !",
  //     textDirection: TextDirection.ltr,
  //   ),
  // ));

  runApp(ChangeNotifierProvider(
    create: (_) => CourseListChangeNotifier(),
    child: const MaterialApp(
      home: OnlineTrainingApp(),
    ),
  ));
}
