import 'package:flutter/material.dart';

class CourseDetails extends StatefulWidget {
  const CourseDetails({super.key});

  @override
  State<CourseDetails> createState() => _CourseDetailsState();
}

class _CourseDetailsState extends State<CourseDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
      ),
      extendBodyBehindAppBar: true,
      body: const SingleChildScrollView(
        child: Column(children: [
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          ),
          Text(
            "Course Details",
            style: TextStyle(
                fontSize: 25.0, color: Color.fromARGB(255, 35, 31, 31)),
          )
        ]),
      ),
    );
  }
}
